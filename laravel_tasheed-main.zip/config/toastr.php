<?php

// return [
//     'options' => [
//         "closeButton" => true,
//         "debug" => false,
//         "newestOnTop" => false,
//         "progressBar" => true,
//         "positionClass" => "toast-top-left",
//         "preventDuplicates" => false,
//         "onclick" => null,
//         "showDuration" => "500",
//         "hideDuration" => "1800",
//         "timeOut" => "5000",
//         'rtl'   => true,
//         "extendedTimeOut" => "1800",
//         "showEasing" => "swing",
//         "hideEasing" => "linear",
//         "showMethod" => "fadeIn",
//         "hideMethod" => "fadeOut"
//     ],
// ];
