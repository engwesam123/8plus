<?php $__env->startSection('title'); ?> <?php echo e(w('Home Page')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div role="main" class="main">

    <?php if(isset($sliders)): ?>
        <div class="owl-carousel owl-carousel-light owl-carousel-light-init-fadeIn owl-theme manual dots-inside dots-horizontal-center show-dots-hover nav-style-diamond custom-nav-with-transparency nav-inside nav-inside-plus nav-dark nav-md nav-font-size-md show-nav-hover mb-0" data-plugin-options="{'autoplayTimeout': 7000}" data-dynamic-height="['700px','700px','700px','550px','500px']" style="height: 700px;">
            <div class="owl-stage-outer">
                <div class="owl-stage">

                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <!-- Carousel Slide 1 -->
                        <div class="owl-item position-relative" style="background:linear-gradient( rgba(0, 0, 0, 0.5) 100%, rgba(0, 0, 0, 0.5)100%),url(<?php echo e($slider->image); ?>); background-size: cover; background-position: center;">

                            <div class="position-absolute bottom-10 w-100pct w-sm-75pct w-lg-50pct appear-animation" data-appear-animation=" <?php if(app()->getlocale() == "en"): ?> fadeInLeftShorter <?php else: ?> fadeInRightShorter <?php endif; ?>" data-appear-animation-delay="500" data-plugin-options="{'minWindowWidth': 0}" style="<?php if(app()->getlocale() == "en"): ?> left: -50px; <?php else: ?> right: -50px;  <?php endif; ?> ">
                                <div class="bg-primary custom-skew-1 mb-5" style="height: 70px;"></div>
                            </div>
                          
                            <div class="container position-relative z-index-1 h-100">
                                <div class="row align-items-end h-100">
                                    <div class="col-10 col-sm-8 col-lg-5 <?php if(app()->getlocale() == "en"): ?>  mr-auto <?php else: ?>  ml-auto <?php endif; ?>">
                                        <h1 class="text-color-light font-weight-light mb-0 text-5 text-md-6 position-relative bottom-7 mb-5 pb-3 appear-animation"
                                            data-appear-animation=" <?php if(app()->getlocale() == "en"): ?> fadeInLeftShorter <?php else: ?> fadeInRightShorter <?php endif; ?>"
                                            data-appear-animation-delay="850"
                                            data-plugin-options="{'minWindowWidth': 0}"><?php echo e($slider->title); ?>

                                        </h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </div>
            </div>
            <div class="owl-nav">
                <button type="button" role="presentation" class="owl-prev"></button>
                <button type="button" role="presentation" class="owl-next"></button>
                 <!-- <a href="<?php echo e(route('UI.projects')); ?>"><?php echo e(w('Portfolio')); ?>>
                 <a href="<?php echo e(route('UI.contact')); ?>"><?php echo e(w('Contact')); ?>> -->
            </div>         

        </div>
    <?php endif; ?>

    <br/><br/>
    <div class="elementor-widget-wrap elementor-element-populated">
			<div class="elementor-element elementor-element-b36d63a elementor-widget elementor-widget-section_title" data-id="b36d63a" data-element_type="widget" data-widget_type="section_title.default">
	<div class="elementor-widget-container">

<div class="pt-section-title-1 text-center">   
   		
     	<h4 class="pt-section-title"><?php echo e(w('How Does')); ?> <span class="imp-word"><?php echo e(w('8PlusIT')); ?></span>  <?php echo e(w('Works')); ?></h4>  
         <br/> <br/>    	   
</div>		</div>
				</div>
				<div class="elementor-section elementor-inner-section elementor-element elementor-element-238ac48 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="238ac48" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c0a0e2c animated fadeInUp" data-id="c0a0e2c" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:300}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-d102f26 elementor-widget elementor-widget-Process_Step" data-id="d102f26" data-element_type="widget" data-widget_type="Process_Step.default">
				<div class="elementor-widget-container">
			<div class="pt-process-step pt-process-2">

          <div class="pt-process-icon"><i class=" flaticon-015-magnifying-glass"></i><span class="pt-process-number">1</span></div>    
    <div class="pt-process-info">
        <h4 class="pt-process-title"><?php echo e(w('Research Project')); ?></h4>        
        <p class="pt-process-description"><?php echo e(w('We are collect requirements to prepare every details for project')); ?> </p>
    </div>
</div>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-8f1df33 animated fadeInUp" data-id="8f1df33" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:600}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-84e3c3b elementor-widget elementor-widget-Process_Step" data-id="84e3c3b" data-element_type="widget" data-widget_type="Process_Step.default">
				<div class="elementor-widget-container">
			<div class="pt-process-step pt-process-2">

          <div class="pt-process-icon"><i class=" flaticon-012-fingerprint"></i><span class="pt-process-number">2</span></div>    
    <div class="pt-process-info">
        <h4 class="pt-process-title"><?php echo e(w('Find Ideas')); ?></h4>        
        <p class="pt-process-description"><?php echo e(w('The most important are ideas so we care about them and thinking out of the box')); ?> </p>
    </div>
</div>

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-17555e3 animated fadeInUp" data-id="17555e3" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:900}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4c9f2db elementor-widget elementor-widget-Process_Step" data-id="4c9f2db" data-element_type="widget" data-widget_type="Process_Step.default">
				<div class="pt-process-step pt-process-2">

          <div class="pt-process-icon"><i class=" flaticon-target"></i><span class="pt-process-number">3</span></div>    
    <div class="pt-process-info">
        <h4 class="pt-process-title"><?php echo e(w('Start implement')); ?> </h4>        
        <p class="pt-process-description"><?php echo e(w('Now The time for implementing the ideas and convert it to a real project')); ?> </p>
    </div>
</div><div class="elementor-widget-container">
			

		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d8cbf50 animated fadeInUp" data-id="d8cbf50" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;,&quot;animation_delay&quot;:1200}">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5ee6d79 elementor-widget elementor-widget-Process_Step" data-id="5ee6d79" data-element_type="widget" data-widget_type="Process_Step.default">
				<div class="elementor-widget-container">
			<div class="pt-process-step pt-process-2">

          <div class="pt-process-icon"><i class=" flaticon-016-mobile-phone"></i><span class="pt-process-number">4</span></div>    
    <div class="pt-process-info">
        <h4 class="pt-process-title"><?php echo e(w('Reach Target')); ?></h4>        
        <p class="pt-process-description"><?php echo e(w('With efficiency team, we can reach to the target and succes')); ?> </p>
    </div>
                         </div>
                    </div>
	            </div>
	    	</div>
		</div>
	  </div>
   </div>
</div>
<br/><br/>
<br/><br/>
 <main id="main">

<!-- ======= Services Section ======= -->
<section id="services" class="services">
    <div class="container">

        <div class="section-title aos-init aos-animate" data-aos="fade-up">
            <div class="ourServices"><?php echo e(w('Our Services')); ?></div>
        </div>
        <br/><br/>
        <div class="row">
                     <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0 text-center">
                     <div data-aos="fade-up" class="aos-init aos-animate" data-aos-delay="100">
                        <div class="icon"><img src="https://www.nstechs.net/storage/upload/rPGaH2lIQYNTIDgesCRPg3l4YSa91gZI6aniO4nN.svg"></div>
                        <h4 class="title"><a href="#"><?php echo e(w('Web Development')); ?></a></h4>

                    </div>
                </div>
                     <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0 text-center">
                    <div data-aos="fade-up" class="aos-init aos-animate" data-aos-delay="100">
                        <div class="icon"><img src="https://www.nstechs.net/storage/upload/eeOpqIYuB9avu57lqDLjdXf2m0kBYktPNTH9TItC.svg"></div>
                        <h4 class="title"><a href="#"><?php echo e(w('Mobile Applications')); ?></a></h4>

                    </div>
                </div>
                    <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0 text-center">
                    <div data-aos="fade-up" class="aos-init" data-aos-delay="100">
                        <div class="icon"><img src="https://www.nstechs.net/storage/upload/I1b38dfKEC8rgy3tSKfiscMzft7fVNTE0PkEeb7q.svg"></div>
                        <h4 class="title"><a href="#"><?php echo e(w('QA')); ?> &amp; <?php echo e(w('Testing')); ?></a></h4>

                    </div>
                </div>
                              
                    <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0 text-center">
                    <div data-aos="fade-up" class="aos-init" data-aos-delay="100">
                        <div class="icon"><img src="https://www.nstechs.net/storage/upload/NgxTBefRc9ryxIYOETjbjXw3yBhPucnuIQ25C2jH.svg"></div>
                        <h4 class="title"><a href="#"><?php echo e(w('Vesual Design')); ?></a></h4>

                    </div>
                </div>
                    <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0 text-center">
                    <div data-aos="fade-up" class="aos-init" data-aos-delay="100">
                        <div class="icon"><img src="https://www.nstechs.net/storage/upload/Jrcz4tbuYnGMhiEdkrMx13Y59UPc9i9OQWEMiHUV.svg"></div>
                        <h4 class="title"><a href="#"><?php echo e(w('System Analysis')); ?></a></h4>

                    </div>
                </div>
                    <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0 text-center">
                    <div data-aos="fade-up" class="aos-init" data-aos-delay="100">
                        <div class="icon"><img src="https://www.nstechs.net/storage/upload/wtEM6BllXZHdSTQSMfG5aPzyUlN6dSJqOQHR82rz.svg"></div>
                        <h4 class="title"><a href="#"><?php echo e(w('Markiting')); ?></a></h4>

                    </div>
                    </div>

                    <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0 text-center">
                    <div data-aos="fade-up" class="aos-init" data-aos-delay="100">
                        <div class="icon"><img src="https://www.nstechs.net/storage/upload/wtEM6BllXZHdSTQSMfG5aPzyUlN6dSJqOQHR82rz.svg"></div>
                        <h4 class="title"><a href="#"><?php echo e(w('Motion Graphic')); ?></a></h4>

                    </div>
                    </div>

                    <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0 text-center">
                    <div data-aos="fade-up" class="aos-init" data-aos-delay="100">
                        <div class="icon"><img src="https://www.nstechs.net/storage/upload/wtEM6BllXZHdSTQSMfG5aPzyUlN6dSJqOQHR82rz.svg"></div>
                        <h4 class="title"><a href="#"><?php echo e(w('Technical Consulting')); ?></a></h4>

                    </div>
                    </div>

           </div>

    </div>
</section><!-- End Services Section -->

<br/><br/>
<br/><br/>
<section id="who_are_we" class="services white">
            <div class="container">

                <div class="section-title aos-init aos-animate" data-aos="fade-up">
                    <div class="ourServices"><?php echo e(w('Why 8Plus ?')); ?></div>
                    <div class="ourServiceDescription pt-1" style="width: 100%;text-align: left;">
                    <br/><br/>
                    <div class="para">
                        <p>
<?php echo e(w('
Because we create with passion
Years of experience in the field of websites and mobile applications
An integrated team of designers, programmers and marketers
We work according to a well-studied methodology that starts from studying the market and customer requirements, designing the commercial identity, programming sites and applications, conducting quality tests on the product, to marketing services and ensuring its spread.
We keep abreast of the latest developments in the technical world to suit the needs of customers
Providing high protection services by specialists against any external penetration
Building websites based on user experience, making them easy to use
We work to make all our works compatible with all browsers and responsive to the screens of all devices
We work on the principle of quality first in all our work
')); ?>

</p>
</div>

                    </div>
                </div>
            </div>
        </section>
        <br/><br/><br/><br/>
        <div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a5977f3" data-id="a5977f3" data-element_type="column">
			<div class="elementor-column-wrap elementor-element-populated">
							<div class="elementor-widget-wrap">
						<div class="elementor-element elementor-element-ffdecbc elementor-widget elementor-widget-spacer" data-id="ffdecbc" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
				<div class="elementor-element-custom_font_size elementor-element-custom_line_height elementor-element-custom_font_weight elementor-element elementor-element-95f9924 elementor-widget elementor-widget-text-editor" data-id="95f9924" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
								<div class="elementor-text-editor elementor-clearfix">
				<!-- <h5><?php echo e(w('Portfolio')); ?></h5>		 -->
            			</div>
					</div>
				</div>
				<div class="elementor-element elementor-element-1168481 elementor-widget elementor-widget-heading" data-id="1168481" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default"><?php echo e(w('Portfolio')); ?></h2>		</div>
				</div>
				<div class="elementor-element elementor-element-cfcaffa elementor-widget elementor-widget-gt3-core-portfolio" data-id="cfcaffa" data-element_type="widget" data-widget_type="gt3-core-portfolio.default">
				<div class="elementor-widget-container">
				<div class="portfolio_wrapper show_type_grid hover_type4 packery_type_2 elementor items4 grid_type_square testimonials_has_grid_gap" data-settings="{&quot;pagination_en&quot;:false,&quot;show_title&quot;:true,&quot;show_category&quot;:true,&quot;use_filter&quot;:true,&quot;lazyload&quot;:&quot;yes&quot;,&quot;load_items&quot;:&quot;4&quot;,&quot;grid_gap&quot;:5,&quot;gap_value&quot;:5,&quot;gap_unit&quot;:&quot;px&quot;,&quot;query&quot;:{&quot;post_status&quot;:[&quot;publish&quot;],&quot;post_type&quot;:&quot;portfolio&quot;,&quot;posts_per_page&quot;:&quot;4&quot;,&quot;paged&quot;:1,&quot;exclude&quot;:[97,95,93,91,89,87]},&quot;type&quot;:&quot;grid&quot;,&quot;random&quot;:false,&quot;render_index&quot;:&quot;6&quot;,&quot;settings&quot;:{&quot;grid_type&quot;:&quot;square&quot;,&quot;cols&quot;:4,&quot;show_type&quot;:&quot;grid&quot;,&quot;packery_type&quot;:2,&quot;lazyload&quot;:&quot;yes&quot;,&quot;grid_gap&quot;:5},&quot;cols&quot;:4,&quot;grid_type&quot;:&quot;square&quot;}" data-post-index="6">
					<div class="isotope-filter isotope-filter--links">
				<a href="https://afkaar-sa.com/" data-filter="*" class="active" data-count="6"><?php echo e(w('Success Partners')); ?></a>	
            		</div>
				<div class="isotope_wrapper gt3_isotope_parent items_list gt3_clear" style="position: relative; height: 2476.13px;">
			<div class="isotope_item packery_blog_item_1 loaded lazy_loaded" style="position: absolute; right: 0%; top: 0px;"><div class="wrapper"><a href="https://afkaar-sa.com/index.php/portfolio/moments-matter-event-studio/" class="lightbox" title="Moments Matter Event Studio"><div class="img_wrap"><div class="img"><div class="gt3_portfolio_list__image-placeholder gt3_lazyload__placeholder" style="padding-bottom:100%;background-color:#E05E6E;"></div><img data-srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works01-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works01-420x420.jpg 420w" data-src="https://afkaar-sa.com/wp-content/uploads/2020/03/works01-400x400.jpg" data-sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px" src="https://afkaar-sa.com/wp-content/uploads/2020/03/works01-400x400.jpg" title="works01" alt="" class="gt3_lazyload_loaded" srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works01-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works01-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works01-420x420.jpg 420w" sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px"></div></div><div class="text_wrap"><h4 class="title">Moments Matter Event Studio</h4></div></a></div></div><div class="isotope_item packery_blog_item_2 loaded lazy_loaded" style="position: absolute; right: 0%; top: 412.688px;"><div class="wrapper"><a href="https://afkaar-sa.com/index.php/portfolio/more-powered-macbook-pro-x/" class="lightbox" title="More Powered Macbook Pro X"><div class="img_wrap"><div class="img"><div class="gt3_portfolio_list__image-placeholder gt3_lazyload__placeholder" style="padding-bottom:100%;background-color:#1E2330;"></div><img data-srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works02-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works02-420x420.jpg 420w" data-src="https://afkaar-sa.com/wp-content/uploads/2020/03/works02-400x400.jpg" data-sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px" src="https://afkaar-sa.com/wp-content/uploads/2020/03/works02-400x400.jpg" title="works02" alt="" class="gt3_lazyload_loaded" srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works02-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works02-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works02-420x420.jpg 420w" sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px"></div></div><div class="text_wrap"><h4 class="title">More Powered Macbook Pro X</h4></div></a></div></div><div class="isotope_item packery_blog_item_3 loaded lazy_loaded" style="position: absolute; right: 0%; top: 825.376px;"><div class="wrapper"><a href="https://afkaar-sa.com/index.php/portfolio/stans-office-online-gateway/" class="lightbox" title="Stan’s Office Online Gateway"><div class="img_wrap"><div class="img"><div class="gt3_portfolio_list__image-placeholder gt3_lazyload__placeholder" style="padding-bottom:100%;background-color:#A87CB0;"></div><img data-srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works03-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works03-420x420.jpg 420w" data-src="https://afkaar-sa.com/wp-content/uploads/2020/03/works03-400x400.jpg" data-sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px" src="https://afkaar-sa.com/wp-content/uploads/2020/03/works03-400x400.jpg" title="works03" alt="" class="gt3_lazyload_loaded" srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works03-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works03-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works03-420x420.jpg 420w" sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px"></div></div><div class="text_wrap"><h4 class="title">Stan’s Office Online Gateway</h4></div></a></div></div><div class="isotope_item packery_blog_item_4 loaded lazy_loaded" style="position: absolute; right: 0%; top: 1238.06px;"><div class="wrapper"><a href="https://afkaar-sa.com/index.php/portfolio/david-courtney-ios-application/" class="lightbox" title="David Courtney IOS Application"><div class="img_wrap"><div class="img"><div class="gt3_portfolio_list__image-placeholder gt3_lazyload__placeholder" style="padding-bottom:100%;background-color:#9D678B;"></div><img data-srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works04-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works04-420x420.jpg 420w" data-src="https://afkaar-sa.com/wp-content/uploads/2020/03/works04-400x400.jpg" data-sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px" src="https://afkaar-sa.com/wp-content/uploads/2020/03/works04-400x400.jpg" title="works04" alt="" class="gt3_lazyload_loaded" srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works04-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works04-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works04-420x420.jpg 420w" sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px"></div></div><div class="text_wrap"><h4 class="title">David Courtney IOS Application</h4></div></a></div></div><div class="isotope_item packery_blog_item_5 lazy_loaded loaded" style="position: absolute; right: 0%; top: 1650.75px;"><div class="wrapper"><a href="https://afkaar-sa.com/index.php/portfolio/daria-e-commerce-ios-application/" class="lightbox" title="Daria e-Commerce IOS Application"><div class="img_wrap"><div class="img"><div class="gt3_portfolio_list__image-placeholder gt3_lazyload__placeholder" style="padding-bottom:100%;background-color:#A9C5C6;"></div><img data-srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works05-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works05-420x420.jpg 420w" data-src="https://afkaar-sa.com/wp-content/uploads/2020/03/works05-400x400.jpg" data-sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px" src="https://afkaar-sa.com/wp-content/uploads/2020/03/works05-400x400.jpg" title="works05" alt="" class="gt3_lazyload_loaded" srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works05-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works05-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works05-420x420.jpg 420w" sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px"></div></div><div class="text_wrap"><h4 class="title">Daria e-Commerce IOS Application</h4></div></a></div></div><div class="isotope_item packery_blog_item_6 loaded lazy_loaded" style="position: absolute; right: 0%; top: 2063.44px;"><div class="wrapper"><a href="https://afkaar-sa.com/index.php/portfolio/get-yo-tacos-ios-application/" class="lightbox" title="Get Yo Tacos IOS Application"><div class="img_wrap"><div class="img"><div class="gt3_portfolio_list__image-placeholder gt3_lazyload__placeholder" style="padding-bottom:100%;background-color:#DCCEE3;"></div><img data-srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works06-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works06-420x420.jpg 420w" data-src="https://afkaar-sa.com/wp-content/uploads/2020/03/works06-400x400.jpg" data-sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px" src="https://afkaar-sa.com/wp-content/uploads/2020/03/works06-400x400.jpg" title="works06" alt="" class="gt3_lazyload_loaded" srcset="https://afkaar-sa.com/wp-content/uploads/2020/03/works06-800x800.jpg 800w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-500x500.jpg 500w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-480x480.jpg 480w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-400x400.jpg 400w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-300x300.jpg 300w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-496x496.jpg 496w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-384x384.jpg 384w, https://afkaar-sa.com/wp-content/uploads/2020/03/works06-600x600.jpg 600w,https://afkaar-sa.com/wp-content/uploads/2020/03/works06-420x420.jpg 420w" sizes="(min-width: 2000px) 800px, (min-width: 1921px) 500px, (min-width: 1600px) 480px, (min-width: 1200px) 400px, (min-width: 992px) 300px, (min-width: 768px) 496px, (min-width: 600px) 384px, (min-width: 420px) 600px, (max-width: 600px) 420px"></div></div><div class="text_wrap"><h4 class="title">Get Yo Tacos IOS Application</h4></div></a></div></div>		</div>
			                         </div>
		                     	</div>
			            	</div>
						</div>
					</div>
		        </div>
			</div>
		</div>

    <!-- <?php if(isset($about)): ?>
        <div class="container">
            <div class="row mt-4 mt-lg-5 mb-4 py-4">
                <div class="col-lg-4">
                    <h2 class="mb-0 text-color-dark"><?php echo e($about->page_name); ?></h2>
                    <p class="lead text-capitalize"><?php echo e($about->title); ?></p>
                </div>
                <div class="col-lg-2 text-center d-none d-lg-block">
                    <img alt="<?php echo e(w('Blog Name')); ?>" src="<?php echo e(asset('frontend/img/dotted-line-angle.png')); ?>" class="img-fluid"  />
                </div>
                <div class="col-lg-6">
                    <p><?php echo $about->short_content; ?></p>
                    <a class="mt-3" href="<?php echo e(route('UI.aboutCompany')); ?>">
                        <?php echo e(w('Learn More')); ?> <i class="fas fa-long-arrow-alt-right"></i></a>
                </div>
            </div>
        </div>
    <?php endif; ?> -->

    <!-- <?php if($services->count() > 0): ?>
        <section class="section section-tertiary section-no-border section-custom-construction">
            <div class="container">
                <div class="row pt-4">
                    <div class="col">
                        <h2 class="mb-0 text-color-dark"><?php echo e(w('Services')); ?></h2>
                        <p class="lead"><?php echo e(w('Serving large industrial projects')); ?>.</p>
                    </div>
                </div>

                <div class="row mt-4">
                    <?php if(isset($services)): ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6">
                                <div class="feature-box feature-box-style-2 custom-feature-box mb-4 appear-animation" data-appear-animation="fadeInUp" data-appear-animation-delay="300">
                                    <div class="feature-box-icon w-auto">
                                        <img src="<?php echo e($service->image); ?>" alt="<?php echo e(w('Blog Name')); ?> - <?php echo e($service->name); ?> " class="img-fluid" width="55" />
                                    </div>
                                    <div class="feature-box-info ml-3">
                                        <h4 class="mb-2"><?php echo e($service->name); ?></h4>
                                        <p><?php echo e($service->description); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?> -->

                </div>
            </div>
        </section>
    <?php endif; ?>

</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_tasheed-main/resources/views/frontend/index.blade.php ENDPATH**/ ?>