<?php $__env->startSection('content'); ?>

    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="kt-portlet">
                    <form id="form_input" action="<?php echo e(route('updateProfile')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                    <div class="kt-portlet__body">
                        <?php echo $__env->make('Manager.included.notfication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <!--begin::Widget -->
                            <div class="row">
                                <div class="col-md-12 mb-5 text-center">
                                    <div class="kt-avatar kt-avatar--outline kt-avatar--circle" >
                                        <div class="kt-avatar__holder" id="imagePreview"
                                             style="background-image: url(<?php echo e($user->image); ?>)">
                                        </div>
                                        <label class="kt-avatar__upload" data-toggle="kt-tooltip" title="" data-original-title="تغير الصورة">
                                            <i class="fa fa-pen"></i>
                                            <input type="file" name="image"  id="imageUpload">
                                        </label>
                                        <span class="kt-avatar__cancel" data-toggle="kt-tooltip" title="" data-original-title="تغير الصورة">
                                                <i class="fa fa-times"></i>
                                            </span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t("Name")); ?></label>
                                        <input  type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t("Email")); ?></label>
                                        <input  type="text" name="email"  value="<?php echo e($user->email); ?>" class="form-control" >
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t("Current Password")); ?></label>
                                        <input type="password" name="current_password" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t("New Password")); ?></label>
                                        <input type="password" name="new_password" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t("Confirm Password")); ?></label>
                                        <input type="password" name="confirm_password" class="form-control">
                                    </div>
                                </div>
                            </div>
                        <!--end::Widget -->
                    </div>
                    <div class="kt-portlet__foot">

                        <div class="kt-form__actions">
                            <button type="submit" class="btn btn-primary"><?php echo e(t("Update Data")); ?></button>
                        </div>
                    </div>
                    </form>

                </div>
            </div>

        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>

        <?php echo $validator->selector('#form_input'); ?>



    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Manager.included.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/Manager/dashboard/profile/index.blade.php ENDPATH**/ ?>