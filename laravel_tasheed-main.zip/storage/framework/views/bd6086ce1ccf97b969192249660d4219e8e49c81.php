<?php $__env->startSection('content'); ?>


    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
        <div class="row">
            <div class="col-md-12">
            <?php echo $__env->make('Manager.included.notfication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--begin::Portlet-->
                <div class="kt-portlet">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                <?php echo e(t("Settings")); ?>

                            </h3>
                        </div>
                    </div>


                    <!--begin::Form-->
                    <form autocomplete="off" id="form_input" class="kt-form" action="<?php echo e(route('setting.update',1)); ?>"
                          method="POST" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>
                        <div class="kt-portlet__body">

                            <div class="row text-center">

                                <div class="col-md-3 ">
                                    <div class="kt-avatar kt-avatar--outline kt-avatar--circle-" >
                                        <div class="kt-avatar__holder" id="imagePreview3" style="background-image: url(<?php echo e($setting->default_logo); ?>);"></div>
                                        <label class="kt-avatar__upload" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-pen"></i>
                                            <input type="file" name="default_logo" id="imageUpload3" >
                                        </label>
                                        <span class="kt-avatar__cancel" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-times"></i>
                                        </span>
                                    </div><br>
                                    <label for=""><?php echo e(t("Default Logo")); ?></label>
                                </div>

                                <div class="col-md-3 ">
                                    <div class="kt-avatar kt-avatar--outline kt-avatar--circle-" >
                                        <div class="kt-avatar__holder" id="imagePreview" style="background-image: url(<?php echo e($setting->logo); ?>);"></div>
                                        <label class="kt-avatar__upload" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-pen"></i>
                                            <input type="file" name="logo" id="imageUpload" >
                                        </label>
                                        <span class="kt-avatar__cancel" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-times"></i>
                                        </span>
                                    </div><br>
                                    <label for=""><?php echo e(t("Logo")); ?></label>
                                </div>

                                <div class="col-md-3  ">

                                    <div class="kt-avatar kt-avatar--outline kt-avatar--circle-" >
                                        <div class="kt-avatar__holder" id="imagePreview2" style="background-image: url(<?php echo e($setting->miniLogo); ?>);"></div>
                                        <label  class="kt-avatar__upload mr-4" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-pen"></i>
                                            <input type="file" name="miniLogo" id="imageUpload2" >
                                        </label>
                                        <span class="kt-avatar__cancel" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-times"></i>
                                        </span>
                                    </div><br>
                                    <label class="ml-3" for=""><?php echo e(t("Mini Logo")); ?></label>

                                </div>

                                <div class="col-md-3  ">

                                    <div class="kt-avatar kt-avatar--outline kt-avatar--circle-" >
                                        <div class="kt-avatar__holder" id="imagePreview4" style="background-image: url(<?php echo e($setting->file_image); ?>);"></div>
                                        <label  class="kt-avatar__upload mr-4" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-pen"></i>
                                            <input type="file" name="file" id="imageUpload4" >
                                        </label>
                                        <span class="kt-avatar__cancel" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-times"></i>
                                        </span>
                                    </div><br>
                                    <label class="ml-3" for=""><?php echo e(t("Pdf File")); ?></label>

                                </div>

                            </div><br>
                            <h3 style="margin-bottom: 30px"><?php echo e(t("Main Data")); ?></h3>

                            <div class="row">

                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get("site." . $local . ".Site Name"); ?> </label>

                                            <input type="text" value="<?php echo e($setting->translate($local)->blog_name); ?>"
                                            name="<?php echo e($local); ?>[blog_name]" class="form-control" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t('Email')); ?> </label>
                                        <input value="<?php echo e($setting->email); ?>" type="text" name="email" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t('Phone')); ?> </label>
                                        <input value="<?php echo e($setting->phone); ?>" type="text" name="phone" class="form-control">
                                    </div>
                                </div>


                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get("site." . $local . ".Address"); ?> </label>

                                            <input type="text" value="<?php echo e($setting->translate($local)->address); ?>"
                                            name="<?php echo e($local); ?>[address]" class="form-control" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </div>
                            <h3 style="margin-bottom: 30px"><?php echo e(t("Socila Media")); ?></h3>

                            <div class="row">

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t('Instagram')); ?> </label>
                                        <input value="<?php echo e($setting->instagram); ?>" type="text" name="instagram" class="form-control" >
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t('Linkedin')); ?> </label>
                                        <input value="<?php echo e($setting->linkedin); ?>" type="text" name="linkedin" class="form-control" >
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t('Facebook')); ?> </label>
                                        <input value="<?php echo e($setting->facebook); ?>" type="text" name="facebook" class="form-control" >
                                    </div>
                                </div>
                               
                               
                            </div>

                            <div class="row">
                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleFormControlTextarea1"><?php echo app('translator')->get("site." . $local . ".Description"); ?></label>
                                            <textarea class="form-control" name="<?php echo e($local); ?>[description]"
                                                id="exampleFormControlTextarea1"
                                                rows="6"><?php echo e($setting->translate($local)->description); ?></textarea>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>


                            <div class="row">
                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get("site." . $local . ".Keywords"); ?> </label>

                                            <input type="text" value="<?php echo e($setting->translate($local)->keywords); ?>"
                                            name="<?php echo e($local); ?>[keywords]" class="form-control" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>



                            

                        </div>

                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <button type="submit" class="btn btn-primary"><?php echo e(t('Update Data')); ?></button>
                                <a href="<?php echo e(route('dashboard')); ?>">
                                    <button type="button" class="btn btn-secondary"><?php echo e(t('Reverse')); ?></button>
                                </a>
                            </div>
                        </div>
                    </form>

                    <!--end::Form-->
                </div>

                <!--end::Portlet-->


                <!--end::Portlet-->
            </div>

        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>

        <?php echo $validator->selector('#form_input'); ?>




    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('Manager.included.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_tasheed-main/resources/views/Manager/dashboard/setting/edit.blade.php ENDPATH**/ ?>