<?php $__env->startSection('content'); ?>

    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
        <?php echo $__env->make('Manager.included.notfication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="kt-portlet kt-portlet--mobile">
            <div class="kt-portlet__head kt-portlet__head--lg">
                <div class="kt-portlet__head-label">
                <span class="kt-portlet__head-icon">
                    <i class="kt-font-brand flaticon2-line-chart"></i>
                </span>
                    <h3 class="kt-portlet__head-title">
                        <?php echo e(t("Clients Table")); ?>

                    </h3>
                </div>
                <div class="kt-portlet__head-toolbar">
                    <div class="kt-portlet__head-wrapper">
                        <div class="dropdown dropdown-inline">

                            <a href="<?php echo e(route('company.add')); ?>">
                                <button type="button" class="btn btn-brand btn-icon-sm btn-index-add d-flex align-baseline"  aria-haspopup="true" aria-expanded="false">
                                    <i class="fal fa-plus"></i>  <?php echo e(t("Add New")); ?>

                                </button>
                            </a>

                        </div>
                    </div>
                </div>
            </div>
            
            <div class="kt-portlet__body">
            
            <?php echo $__env->make('Manager.included.notfication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!--end: Search Form -->
            </div>
            <div class="kt-portlet__body kt-portlet__body--fit">

                <!--begin: Datatable -->
                <div class="kt-datatable kt-datatable--default kt-datatable--brand kt-datatable--loaded"
                     id="local_data">
                    <div class="card-body">

                      <div class="table-responsive">
                        <table id="adminDataTable" class="datatable table table-bordered table-striped text-center ">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(t("Image")); ?></th>
                                <th><?php echo e(t("Name")); ?></th>
                                <th><?php echo e(t("Actions")); ?></th>
                            </tr>
                            </thead>
                            <tbody>


                            </tbody>
                        </table>
                      </div>

                        <div id="confirmModal" class="modal fade" role="dialog">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h2 class="modal-title"> <?php echo e(t('Confirmation')); ?> </h2>
                                    </div>
                                    <div class="modal-body">
                                        <h4 align="center" style="margin:0;"><?php echo e(t('Are you sure you want to remove this item ?')); ?> </h4>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" name="ok_button" id="ok_button"
                                                style="background-color: rgb(236, 67, 67);color:white" class="btn "><?php echo e(t('Delete')); ?>

                                        </button>
                                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(t('Cancle')); ?>

                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                    <!--end: Datatable -->
                </div>
            </div>
        </div>

    <?php $__env->startPush('scripts'); ?>
                   
                <script type="text/javascript">
                    var id;
                    $(document).on('click', '.delete', function(){
                         id = $(this).attr('id');
                            $('#confirmModal').modal('show');
                    });
                    $('#ok_button').click(function(){
                        var url = "<?php echo e(route('company.delete',':id')); ?>";
                        url = url.replace(':id', id);
                        $.ajax({
                            url:url,
                            type: "POST",

                            success:function(data)
                            {
                                setTimeout(function(){
                                $('#confirmModal').modal('hide');
                                $('#adminDataTable').DataTable().ajax.reload();
                                }, 400);
                                toastr.success("<?php echo e(t("Success To Delete Item")); ?>")
                            }
                        })
                    });
                </script>

            <script type="text/javascript">

                $(function () {

                    var table = $('.datatable').DataTable({
                        language: {
                            url: "<?php echo app('translator')->get('site.datatable_lang'); ?>"
                        },
                        processing: true,
                        lengthChange:false,
                        info: false,
                        serverSide: true,
                        ajax: "<?php echo e(route('company.getCompanyData')); ?>",
                        columns: [
                            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                            {data: 'image', name: 'image'},
                            {data: 'name', name: 'name'},
                            {data: 'action', name: 'action', orderable: false, searchable: false},
                        ]

                    });

                });
            </script>



    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Manager.included.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/Manager/dashboard/company/index.blade.php ENDPATH**/ ?>