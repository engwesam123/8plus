<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('backend/vendor/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('backend/vendor/vendors/dropzone/dist/dropzone.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
        <div class="row">
            <div class="col-md-12">
            <?php echo $__env->make('Manager.included.notfication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--begin::Portlet-->
                <div class="kt-portlet">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                <?php echo e(t("Add Mutli Image For - ")); ?> <?php echo e($project->project_name); ?>

                            </h3>
                        </div>
                    </div>




                        <div class="kt-portlet__body">
                            <form enctype="multipart/form-data" action="<?php echo e(route('project.storeImages',$project->id)); ?>" method="POST" class="dropzone" id="dropzone">
                                <?php echo csrf_field(); ?>
                                <div class="fallback">
                                  <input name="file" type="file" multiple />

                                </div>
                            </form>


                            <div class="row text-cente">
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-2 p-3 text-center">
                                        <img class="img-thumbnail mr-2"  src="<?php echo e($image->image); ?>" alt="">
                                        <?php if(auth()->user()->hasRole('super_admin')): ?>
                                            <a href="<?php echo e(route('project.deleteImage',['id' => $image->id,'project_id' => $project->id])); ?>"
                                                class="btn btn-outline-danger btn-sm text-center mt-3" ><?php echo e(t('Delete')); ?>

                                        </a>
                                        <?php else: ?>

                                            <a  class="disabled btn btn-outline-danger btn-sm text-center mt-3" ><?php echo e(t('Delete')); ?></a>
                                        <?php endif; ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <br><br>

                        </div>



                    <!--end::Form-->
                </div>

                <!--end::Portlet-->


                <!--end::Portlet-->
            </div>

        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>

        <?php echo $validator->selector('#form_input'); ?>


        <script src="<?php echo e(asset('backend/vendor/vendors/dropzone/dist/dropzone.js')); ?>" type="text/javascript"></script>


    <script type="text/javascript">
        // Dropzone.autoDiscover = false;
        // $(".dropzone").dropzone({
        //     init: function() {
        //         myDropzone = this;
        //         $.ajax({
        //         url:  "<?php echo e(route('project.uplodedImages',$project->id)); ?>",
        //         type: 'get',
        //         data: {request: 2},
        //         dataType: 'json',
        //         success: function(response){
        //             $.each(response.data, function(key,value) {
        //                 var mockFile = { filename: value.image, size: value.image };
        //                 myDropzone.emit("addedfile", mockFile);
        //                 myDropzone.emit("thumbnail", mockFile,value.image);
        //                 myDropzone.emit("complete", mockFile,value.image);
        //             });

        //         }
        //     });
        //     }
        // });

        Dropzone.options.dropzone =
         {
            maxFilesize: 12,
            acceptedFiles: ".jpeg,.jpg,.png,.gif",
            timeout: 5000,
            addRemoveLinks: true,
            init: function () {
                this.on("queuecomplete", function (file) {
                    setTimeout(function(){
                        location.reload()
                    }, 1000);
                });
            },
            success: function(file, response)
            {
                toastr.success("<?php echo e(t('Add Success')); ?>");
            },
            error: function(file, response)
            {
                toastr.error("<?php echo e(t('Something Error')); ?>");

            }
        };






        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('Manager.included.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/Manager/dashboard/project/images.blade.php ENDPATH**/ ?>