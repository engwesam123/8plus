  
<?php if(session()->has('addMassage')): ?>
    <div class="alert alert-dismissible fade show" style="background-color:#3ec77c;color:white" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong> <?php echo e(t("Notfication")); ?> : </strong> <?php echo e(session()->get('addMassage')); ?>.
    </div>
<?php endif; ?>






<?php if(session()->has('editMassage')): ?>
    <div class="alert alert-dismissible fade show" style="background-color:#3ec77c;color:white" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong> <?php echo e(t("Notfication")); ?>  : </strong> <?php echo e(session()->get('editMassage')); ?>.
    </div>
<?php endif; ?>


<?php if(session()->has('deleteMassage')): ?>
    <div class="alert alert-dismissible fade show" style="background-color:#3ec77c;color:white" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong> <?php echo e(t("Notfication")); ?>  : </strong> <?php echo e(session()->get('deleteMassage')); ?>.
    </div>
<?php endif; ?>


<?php if($errors->count() > 0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



    <div class="alert alert-dismissible fade show" style="background-color:#e43b62;color:white" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        <strong><?php echo e(t("Notfication")); ?>  : </strong> <?php echo e($error); ?>.
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>




<div class="flash-message alert alert-dismissible fade show" style="background-color:#3ec77c;color:white;display:none" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
    <strong>تنبيه :  تم تغير الحالة بنجاح

    </strong>
 </div>
<?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/Manager/included/notfication.blade.php ENDPATH**/ ?>