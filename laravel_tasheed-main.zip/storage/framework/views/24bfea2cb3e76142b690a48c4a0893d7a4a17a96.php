<?php $__env->startSection('title'); ?><?php echo e(w('About Company')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div role="main" class="main">
    <section class="section section-tertiary section-no-border pb-3 mt-0">
        <div class="container">
            <div class="row justify-content-end mt-4">
                <div class="col-lg-10 pt-4 mt-4 text-right">
                    <h1 class="text-uppercase font-weight-light mt-4 pt-3 text-color-primary"><?php echo e(w('Company')); ?></h1>
                </div>
            </div>
        </div>
    </section>

    <div class="container">

        <div class="row pt-2">
            <div class="col-lg-3">
                <aside class="sidebar" id="sidebar" data-plugin-sticky data-plugin-options="{'minWidth': 991, 'containerSelector': '.container', 'padding': {'top': 110}}">

                    <ul class="nav nav-list flex-column mb-4 show-bg-active">
                        <li class="nav-item"><a class="nav-link" data-hash data-hash-offset="110" href="#who-we-are"><?php echo e(w('Who We Are')); ?></a></li>
                        <li class="nav-item"><a class="nav-link" data-hash data-hash-offset="110" href="#history"><?php echo e(w('History')); ?></a></li>
                        <li class="nav-item"><a class="nav-link" data-hash data-hash-offset="110" href="#mission-vision"><?php echo e(w('Mission')); ?> &amp; <?php echo e(w('Vision')); ?></a></li>
                        <li class="nav-item"><a class="nav-link" data-hash data-hash-offset="110" href="#leadership"><?php echo e(w('Leadership')); ?></a></li>
                        <li class="nav-item"><a class="nav-link" data-hash data-hash-offset="110" href="#partners"><?php echo e(w('Partners')); ?></a></li>
                        <li class="nav-item"><a class="nav-link" data-hash data-hash-offset="110" target="_black" href="<?php echo e(asset('frontend/img/organization-chart.jpg')); ?>"><?php echo e(w('Organizational Chart')); ?></a></li>

                    </ul>

                </aside>
            </div>

            <div class="col-lg-9">

                <section id="who-we-are" class="mb-4">
                    <?php if(isset($about)): ?>
                        <?php if($about->images->count() > 0): ?>
                            <div class="owl-carousel nav-inside show-nav-hover dots-inside mt-3 mb-4" data-plugin-options="{'items': 1, 'loop': true, 'autoplay': true, 'autoplayTimeout': 5000, 'autoplayHoverPause': true, 'nav': true, 'dots': true, 'animateOut': 'fadeOut'}">
                                <?php $__currentLoopData = $about->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <img src="<?php echo e($about_image->image); ?>"  alt="<?php echo e(w('Blog Name')); ?> - <?php echo e($about_image->page_name); ?>" />
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <h2 class="mb-0 text-color-dark"><?php echo e($about->page_name); ?></h2>
                        <p class="lead mb-4 mt-4"><?php echo $about->short_content; ?></p>

                        <?php echo $about->long_content; ?>

                    <?php endif; ?>

                </section>

                <?php if(isset($history)): ?>
                    <hr class="solid my-5">
                    <section id="history" class="mb-4">
                        <h2 class="mb-0 text-color-dark"><?php echo e(w('History')); ?></h2>

                        <div class="row">
                            <div class="col-lg-5">
                                <img class=" mb-3 mt-4 appear-animation"  width="100%" data-appear-animation="fadeInUp" data-appear-animation-delay="0" src="<?php echo e($history->image); ?>" alt="<?php echo e(w('Blog Name')); ?> - <?php echo e($history->content); ?>">
                            </div>
                            <div class="col-lg-7">
                            <p class="mt-4 text-justify"><?php echo $history->content; ?> </p>

                                <ul class="list list-unstyled list-primary list-borders">
                                    <?php $__currentLoopData = $history->dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history_date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="pt-2 pb-2 appear-animation"
                                            data-appear-animation="fadeInUp"
                                            data-appear-animation-delay="0">
                                            <span class="text-color-primary text-4"><?php echo e($history_date->history_date); ?> - </span>
                                            <?php if(app()->getlocale() == "ar"): ?>
                                                <?php echo e($history_date->content_ar); ?>

                                            <?php else: ?>
                                                <?php echo e($history_date->content_en); ?>

                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </section>
                <?php endif; ?>



                <?php if(isset($visibles)): ?>
                    <hr class="solid my-5">
                    <section id="mission-vision" class="mb-4">

                        <div class="row mt-4">
                            <?php $__currentLoopData = $visibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visible): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-sm-6 text-center">
                                    <div class="feature-box feature-box-style-4 justify-content-center mt-4 appear-animation" data-appear-animation="fadeInUp" data-appear-animation-delay="0">
                                        <span class="featured-boxes featured-boxes-style-4 p-0 m-0">
                                            <span class="featured-box featured-box-primary featured-box-effect-6 p-0 m-0">
                                                <span class="box-content p-0 m-0">
                                                    <img width="50px" height="50px" src="<?php echo e($visible->image); ?>" alt="<?php echo e(w('Blog Name')); ?> - <?php echo e($visible->title); ?>">
                                                </span>
                                            </span>
                                        </span>
                                        <div class="feature-box-info">
                                            <h2 class="mb-3 text-color-dark"><?php echo e($visible->title); ?></h2>
                                            <p class="mb-4"><?php echo $visible->description; ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </section>
                <?php endif; ?>

                <?php if(isset($leader_ships) && $leader_ships->count() > 0): ?>
                    <hr class="solid my-5">

                    <section id="leadership" class="mb-4">
                        <h2 class="mb-0 text-color-dark"><?php echo e(w('Leadership')); ?></h2>
                        <div class="row mt-4">
                            <?php $__currentLoopData = $leader_ships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leader_ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-md-12">
                                <span class="thumb-info thumb-info-side-image thumb-info-no-zoom no-borders">
                                    <span class="thumb-info-side-image-wrapper p-0">
                                        <img src="<?php echo e($leader_ship->image); ?>" class="img-fluid" alt="<?php echo e(w('Blog Name')); ?> - <?php echo e($leader_ship->name); ?>" style="width: 120px;">
                                    </span>
                                    <span class="thumb-info-caption">
                                        <span class="thumb-info-caption-text">
                                            <h5 class="text-uppercase mb-1"><?php echo e($leader_ship->name); ?> - <small class="font-weight-light"><?php echo e($leader_ship->job); ?> </small></h5>
                                            <p class="mb-0 text-justify"><?php echo e($leader_ship->description); ?></p>
                                        </span>
                                    </span>
                                </span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        </div>

                    </section>
                <?php endif; ?>

                <?php if(isset($partners) && $partners->count() > 0): ?>
                <hr class="solid my-5">
                    <section id="partners" class="mb-4">
                        <h2 class="mb-0 text-color-dark"><?php echo e(w('Partners')); ?></h2>

                        <div class="row">

                                <div class="row">
                                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-md-6 col-sm-12">
                                            <div class="p-4">
                                                <img  data-toggle="tooltip" data-placement="bottom" title="<?php echo e($partner->name); ?>" width="100%" src="<?php echo e($partner->image); ?>" alt="<?php echo e(w('Blog Name')); ?> - <?php echo e($partner->name); ?>">
                                                <p class="mt-4 text-justify"><?php echo e($partner->description); ?></p>
                                            </div>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                        </div>
                    </section>
                <?php endif; ?>

            </div>

        </div>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_tasheed-main/resources/views/frontend/company.blade.php ENDPATH**/ ?>