<?php $__env->startSection('content'); ?>


    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
        <div class="row">
            <div class="col-md-12">
            <?php echo $__env->make('Manager.included.notfication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--begin::Portlet-->
                <div class="kt-portlet">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                <?php echo e(t("Add Client")); ?>

                            </h3>
                        </div>
                    </div>


                    <!--begin::Form-->
                    <form autocomplete="off" id="form_input" class="kt-form" action="<?php echo e(route('company.store')); ?>"
                          method="POST" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>
                        <div class="kt-portlet__body">

                            <div class="row">
                                <div class="col-md-12 text-center mb-5">
                                    <div class="kt-avatar kt-avatar--outline kt-avatar--circle-" >
                                        <div class="kt-avatar__holder" id="imagePreview" style="background-image: url(<?php echo e(asset('backend/img/default.jpg')); ?>);"></div>
                                        <label class="kt-avatar__upload" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-pen"></i>
                                            <input type="file" name="image" id="imageUpload" >
                                        </label>
                                        <span class="kt-avatar__cancel" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-times"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">


                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get("site." . $local . ".Name"); ?> </label>

                                            <input type="text"  value="<?php echo e(old($local.'.name')); ?>" name="<?php echo e($local); ?>[name]" class="form-control" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                        </div>
                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <button type="submit" class="btn btn-primary"><?php echo e(t('Add Data')); ?></button>
                                <a href="<?php echo e(route('company.index')); ?>">
                                    <button type="button" class="btn btn-secondary"><?php echo e(t('Reverse')); ?></button>
                                </a>
                            </div>
                        </div>
                    </form>

                    <!--end::Form-->
                </div>

                <!--end::Portlet-->


                <!--end::Portlet-->
            </div>

        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>

        <?php echo $validator->selector('#form_input'); ?>




    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('Manager.included.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/Manager/dashboard/company/add.blade.php ENDPATH**/ ?>