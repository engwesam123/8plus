<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('backend/vendor/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
        <div class="row">
            <div class="col-md-12">
            <?php echo $__env->make('Manager.included.notfication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--begin::Portlet-->
                <div class="kt-portlet">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                <?php echo e(t("Edit Project")); ?>

                            </h3>
                        </div>
                    </div>


                    <!--begin::Form-->
                    <form autocomplete="off" id="form_input" class="kt-form" action="<?php echo e(route('project.update',$project->id)); ?>"
                          method="POST" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>
                        <div class="kt-portlet__body">

                            <div class="row">
                                <div class="col-md-12 text-center mb-5">
                                    <div class="kt-avatar kt-avatar--outline kt-avatar--circle-" >
                                        <div class="kt-avatar__holder" id="imagePreview" style="background-image: url(<?php echo e($project->image); ?>);"></div>
                                        <label class="kt-avatar__upload" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-pen"></i>
                                            <input type="file" name="image" id="imageUpload" >
                                        </label>
                                        <span class="kt-avatar__cancel" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-times"></i>
                                        </span>
                                        <span class="mt-3 d-block">  W 740 / H 740</span>

                                    </div>
                                </div>
                            </div>

                            <div class="row">


                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get("site." . $local . ".Project Name"); ?> </label>
                                            <input type="text" value="<?php echo e($project->translate($local)->project_name); ?>" name="<?php echo e($local); ?>[project_name]" class="form-control" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo app('translator')->get("site." . $local . ".Client Name"); ?> </label>
                                        <input type="text" value="<?php echo e($project->translate($local)->project_name); ?>" name="<?php echo e($local); ?>[client_name]" class="form-control" aria-describedby="emailHelp">
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get("site." . $local . ".Location"); ?> </label>
                                            <input type="text" value="<?php echo e($project->translate($local)->project_name); ?>" name="<?php echo e($local); ?>[location]" class="form-control" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label><?php echo app('translator')->get("site." . $local . ".Project Type"); ?> </label>
                                            <input type="text" value="<?php echo e($project->translate($local)->project_name); ?>" name="<?php echo e($local); ?>[project_type]" class="form-control" aria-describedby="emailHelp">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                                 <div class="col-md-4">
                                    <label><?php echo e(t("Service")); ?></label>
                                    <select class="form-control select2" multiple name="services_id[]">
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                            <?php $__currentLoopData = $project->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($service->id == $project_service->id ? 'selected' : ''); ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                 </div>


                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t('Project Cost')); ?></label>
                                        <input value="<?php echo e($project->project_cost); ?>" type="text" name="project_cost" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label><?php echo e(t('Project Bulid Date')); ?></label>
                                        <input id="datetimepicker1" value="<?php echo e($project->project_bulid_date); ?>" type="text" name="project_bulid_date" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <br>
                                    <div class="form-group row align-items-center  mb-5">
                                        <label class="col-4 col-form-label"><?php echo e(t("Status")); ?></label>
                                        <div class="col-8">
                                            <span class="kt-switch ">
                                                <label class="mb-0">
                                                    <input  <?php echo e($project->status == 1 ? 'checked' : ''); ?>

                                                    type="checkbox" value="1"  name="status">
                                                    <span></span>
                                                </label>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <br>
                                    <div class="form-group row align-items-center  mb-5">
                                        <label class="col-4 col-form-label"><?php echo e(t("View Status")); ?></label>
                                        <div class="col-8">
                                            <span class="kt-switch ">
                                                <label class="mb-0">
                                                    <input <?php echo e($project->view_status == 1 ? 'checked' : ''); ?>

                                                    type="checkbox"  value="1"  name="view_status">
                                                    <span></span>
                                                </label>
                                            </span>
                                        </div>
                                    </div>
                                </div>


                            </div>

                            <div class="row">
                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleFormControlTextarea1"><?php echo app('translator')->get("site." . $local . ".Description"); ?></label>
                                            <textarea class="form-control" name="<?php echo e($local); ?>[description]"
                                                id="exampleFormControlTextarea1"
                                                rows="6"><?php echo e($project->translate($local)->description); ?></textarea>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <button type="submit" class="btn btn-primary"><?php echo e(t('Update Data')); ?></button>
                                <a href="<?php echo e(route('project.index')); ?>">
                                    <button type="button" class="btn btn-secondary"><?php echo e(t('Reverse')); ?></button>
                                </a>
                            </div>
                        </div>
                    </form>

                    <!--end::Form-->
                </div>

                <!--end::Portlet-->


                <!--end::Portlet-->
            </div>

        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>

        <?php echo $validator->selector('#form_input'); ?>



        <script src="<?php echo e(asset('backend/vendor/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"  type="text/javascript"></script>
        <script src="<?php echo e(asset('backend/vendor/vendors/select2/dist/js/select2.full.js')); ?>" type="text/javascript"></script>

        <script>
            $(function () {
                $('#datetimepicker1').datepicker({
                    autoclose : true,
                    orientation: "top left",
                    changeYear: true,
                    format: "yyyy",
                    viewMode: "years",
                    minViewMode: "years",
                });
            });


            $(document).ready(function () {
                $('.select2').select2();
            });



        </script>

    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('Manager.included.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/Manager/dashboard/project/edit.blade.php ENDPATH**/ ?>