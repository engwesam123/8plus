<?php $__env->startSection('title'); ?><?php echo e(w('About Company')); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div role="main" class="main">

    <div class="container">

        <div class="row pt-5">
            <!-- End portfolio Section -->
                                <?php if($services->count() > 0): ?>
                                    <section class="section section-tertiary section-no-border section-custom-construction" style="background: none;">
                                        <div class="container">
                                            <div class="row col-lg-10 pt-4">
                                                <div class="col ">
                                                    <h2 class="text-uppercase font-weight-light mt-4 pt-3 text-color-primary"><?php echo e(w('Services')); ?></h2>
                                                </div>
                                            </div>


                                        <div class="row mt-4">
                                            <?php if(isset($services)): ?>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-lg-6 "  >
                                                <div class="feature-box feature-box-style-2 custom-feature-box mb-4 appear-animation" style="background: #F7F7F7 !important;     min-height: 350px; padding: 40px; "  data-appear-animation="fadeInUp" data-appear-animation-delay="300">
                                                    <div class="feature-box-icon w-auto" >
                                                        <img src="<?php echo e($service->image); ?>" alt="<?php echo e(w('Blog Name')); ?> - <?php echo e($service->name); ?> " class="img-fluid" width="55" />
                                                            </div>
                                                            <div class="feature-box-info ml-3">
                                                                <h4 class="mb-2"><?php echo e($service->name); ?></h4>
                                                                <p><?php echo e($service->description); ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                            </div>
                            </div>
                            </section>
                            <?php endif; ?>

        </div>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/frontend/services.blade.php ENDPATH**/ ?>