<!DOCTYPE html>


<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>" >
	<head>
		<base href="">
		<meta charset="utf-8" />
		<title><?php echo e(t('Error : 404')); ?></title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" href="<?php echo e(asset('backend/css/bundle.css')); ?>" />
		<link rel="stylesheet" href="<?php echo e(asset('backend/css/style.css')); ?>" />
		<?php if(app()->getlocale() == "ar"): ?>
		<link href="https://fonts.googleapis.com/earlyaccess/notokufiarabic.css" rel="stylesheet">
		<?php else: ?>
			<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap" rel="stylesheet" type="text/css">
		<?php endif; ?>
	</head>

	<body>
		<div class="row justify-content-center align-items-center vh-100 text-center">
			<div class="col-lg-5 col-md-6 col-sm-8">
				<div class="error-page">
					<h1>404</h2>
					<p><?php echo e(t("The Page Not Found")); ?><br>🤔🤔🤔</p>
					<a href="<?php echo e(route('UI.index')); ?>">
						<button><?php echo e(t("Home")); ?></button>
					</a>
			    </div>
			</div>
        </div>
	</body>

</html>
<?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/errors/404.blade.php ENDPATH**/ ?>