<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>" >
	<head>
	    <?php
            $setting = App\Setting::first();
        ?>
        <base href="http://elafsaihati.com/">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimal-ui ,user-scalable=no">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta property="og:image" content="">
        <meta property="og:url" content="<?php echo e(asset('')); ?>">
        <meta property="og:title" content="<?php echo e(isset($setting) ? $setting->blog_name : ''); ?> | <?php echo $__env->yieldContent('title'); ?>">
        <title><?php echo e(isset($setting) ? $setting->blog_name : ''); ?> | <?php echo $__env->yieldContent('title'); ?></title>
        <meta property="og:description" content="<?php echo e(isset($setting) ? $setting->description : ''); ?>">
        <meta name="author" content="elafsaihati.com">
        <meta name="description" content="<?php echo e(isset($setting) ? $setting->description : ''); ?>">
        <meta name="keywords" content="<?php echo e(isset($setting) ? str_replace(' ', ',', $setting->keywords)  : ''); ?>">
        <link rel="icon" href="<?php echo e(isset($setting) ? $setting->miniLogo : ''); ?>"/>
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/bootstrap/css/bootstrap.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('vendor/fontawesome/css/all.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/animate/animate.compat.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/owl.carousel/assets/owl.carousel.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/owl.carousel/assets/owl.theme.default.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/vendor/magnific-popup/magnific-popup.min.css')); ?>">
        <?php if(app()->getlocale() == "en"): ?>
		<link id="googleFonts" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800%7CShadows+Into+Light&display=swap" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/theme.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/theme-elements.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/theme-shop.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/css/demos/demo-construction.css')); ?>">
        <?php else: ?>
		<link href="https://fonts.googleapis.com/earlyaccess/notokufiarabic.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/rtl/css/rtl-theme.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/rtl/css/rtl-theme-elements.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/rtl/css/rtl-theme-shop.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('frontend/rtl/css/demos/rtl-demo-construction.css')); ?>">
        <?php endif; ?>
		<link id="skinCSS" rel="stylesheet" href="<?php echo e(asset('frontend/css/skins/skin-construction.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('frontend/css/custom.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('vendor/toastr/css/toastr.css')); ?>" />
        
		<style>
            .section-custom-construction-2 .owl-carousel .owl-stage{
                display: flex;
                align-items: center;
            }
        </style>
	</head>
	<body data-spy="scroll" data-target="#sidebar" data-offset="120">


		<div class="body">
			<header id="header" class="header-narrow header-semi-transparent-light" data-plugin-options="{'stickyEnabled': true, 'stickyEnableOnBoxed': true, 'stickyEnableOnMobile': true, 'stickyStartAt': 1, 'stickySetTop': '1'}">
				<div class="header-body">
					<div class="header-container container">
						<div class="header-row">
							<div class="header-column">
								<div class="header-row">
									<div class="header-logo">
                                        <?php if(isset($setting)): ?>
                                            <a href="<?php echo e(route('UI.index')); ?>">
                                                <img class="logo-default" width="150" height="70" src="<?php echo e($setting->default_logo); ?>">
                                            </a>
                                            <a href="<?php echo e(route('UI.index')); ?>">
                                                <img class="logo-small d-block d-md-none"  width="90" src="<?php echo e($setting->miniLogo); ?>">
                                                <img class="logo-large d-none d-md-block mt-2"  width="150" src="<?php echo e($setting->logo); ?>">
                                            </a>
                                        <?php endif; ?>
									</div>
								</div>
							</div>
							<div class="header-column justify-content-end">
								<div class="header-row">
									<div class="header-nav header-nav-stripe order-2 order-lg-1">
										<div class="header-nav-main header-nav-main-square header-nav-main-effect-1 header-nav-main-sub-effect-1">
											<nav class="collapse">
												<ul class="nav nav-pills" id="mainNav">
													<li>
														<a class="nav-link <?php echo e(Request::routeIs('UI.index') ? 'active' : ''); ?>"
                                                        href="<?php echo e(route('UI.index')); ?>">
												            <?php echo e(w('Home')); ?>

														</a>
													</li>
													<li>
														<a class="nav-link <?php echo e(Request::routeIs('') ? 'active' : ''); ?>" href="">
												            <?php echo e(w('Services')); ?>

														</a>
													</li>

													<li>
														<a class="nav-link <?php echo e(Request::routeIs('UI.projects') ? 'active' : ''); ?>" href="<?php echo e(route('UI.projects')); ?>">
												            <?php echo e(w('Portfolio')); ?>

														</a>
													</li>
                                                    <li>
														<a class="nav-link <?php echo e(Request::routeIs('') ? 'active' : ''); ?>" href="">
												            <?php echo e(w('Blog')); ?>

														</a>
													</li>
													<li>
														<a class="nav-link <?php echo e(Request::routeIs('UI.contact') ? 'active' : ''); ?>" href="<?php echo e(route('UI.contact')); ?>">
												            <?php echo e(w('Contact')); ?>

														</a>
													</li>
                                                    <li>
														<a class="nav-link <?php echo e(Request::routeIs('UI.aboutCompany') ? 'active' : ''); ?>" href="<?php echo e(route('UI.aboutCompany')); ?>">
												            <?php echo e(w('About us')); ?>

														</a>
													</li>
                                                    <li>
                                                        <?php if(app()->getLocale() == "ar"): ?>
                                                            <a  class="nav-link data-toggle="tooltip" data-placement="bottom" title="<?php echo e(w('English language')); ?>"  href="<?php echo e(LaravelLocalization::getLocalizedURL('en')); ?>">
                                                                <img style="border-radius: 50px" width="25px" height="25px" src="<?php echo e(asset('backend/img/flags/012-uk.svg')); ?>" alt="<?php echo e(w('English language')); ?>">
                                                            </a>
                                                        <?php else: ?>
                                                            <a class="nav-link data-toggle="tooltip" data-placement="bottom" title="<?php echo e(w('Arabic language')); ?>"  href="<?php echo e(LaravelLocalization::getLocalizedURL('ar')); ?>">
                                                                <img style="border-radius: 50px"  width="25px" height="25px" src="<?php echo e(asset('backend/img/flags/008-saudi-arabia.svg')); ?>" alt="<?php echo e(w('Arabic language')); ?>">
                                                            </a>
                                                        <?php endif; ?>

													</li>
												</ul>
											</nav>
										</div>
										<button class="btn header-btn-collapse-nav" data-toggle="collapse" data-target=".header-nav-main nav">
											<i class="fas fa-bars"></i>
										</button>
									</div>
									<div class="header-nav-features header-nav-features-no-border d-none d-sm-block order-1 order-lg-2">
										<ul class="header-social-icons social-icons d-none d-sm-block social-icons-clean ml-0">
                                            <?php if(isset($setting)): ?>
                                                <li class="social-icons-facebook"><a href="<?php echo e($setting->facebook); ?>" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
                                                <li class="social-icons-twitter"><a href="<?php echo e($setting->twitter); ?>" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a></li>
                                                <li class="social-icons-linkedin"><a href="<?php echo e($setting->linkedin); ?>" target="_blank" title="Linkedin"><i class="fab fa-linkedin-in"></i></a></li>
                                            <?php endif; ?>

										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>


            <?php echo $__env->yieldContent('content'); ?>

			<footer id="footer" class="border-top-0">
				<div class="container  py-4">
					<div class="row pt-0 pb-5">
						<div class="col-md-3">
							<a href="<?php echo e(route('UI.index')); ?>" class="mb-4">
								<img alt="<?php echo e(w('Blog Name')); ?>" class="img-fluid logo" width="110" src="<?php echo e($setting->miniLogo); ?>">
							</a>
						</div>
						<div class="col-md-4">
							<div class="row">
								<div class="col-lg-6 mb-2 mt-4">
									<h4><?php echo e(w('Navigation')); ?></h4>
								</div>
							</div>
							<div class="row">
								<div class="col-6 mb-0">
									<ul class="list list-footer-nav">
										<li>
											<a href="<?php echo e(route('UI.index')); ?>">
												<?php echo e(w('Home')); ?>


											</a>
										</li>

                                        <li>
											<a href="<?php echo e(route('UI.projects')); ?>">
												<?php echo e(w('Portfolio')); ?>

											</a>
										</li>

										<li>
											<a href="<?php echo e(route('UI.aboutCompany')); ?>">
												<?php echo e(w('Company')); ?>

											</a>
										</li>

									</ul>
								</div>
								<div class="col-6">
									<ul class="list list-footer-nav">
		
                                        <li>
											<a target="_black" href="<?php echo e($setting->file); ?>">
												<?php echo e(w('Company Profile')); ?>

											</a>
										</li>

                                        <li>
											<a target="_black" href="<?php echo e(asset('frontend/img/organization-chart.jpg')); ?>">
												<?php echo e(w('Organizational Chart')); ?>

											</a>
										</li>

										<li>
											<a href="<?php echo e(route('UI.contact')); ?>">
												<?php echo e(w('Contact')); ?>

											</a>
										</li>

									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-5 mt-4">

                            <?php if(isset($setting)): ?>
                                <h4><?php echo e(w('Contact Us')); ?></h4>

                                <p> <i class="far fa-map-marker-alt   <?php if(app()->getlocale() == 'en'): ?> mr-2 <?php else: ?> ml-2 <?php endif; ?> "></i> <span dir="ltr"><?php echo e($setting->address); ?></span></p>
							    <p> <i class="far fa-phone <?php if(app()->getlocale() == 'en'): ?> mr-2 <?php else: ?> ml-2 <?php endif; ?>"></i> <span dir="ltr"><?php echo e($setting->phone); ?></span></p>
                                <p><i class="far fa-envelope <?php if(app()->getlocale() == 'en'): ?> mr-2 <?php else: ?> ml-2 <?php endif; ?>"></i> <a href="mailto:<?php echo e($setting->email); ?>"> <?php echo e($setting->email); ?></a></p>
                            <?php endif; ?>

						</div>
					</div>

					<div class="footer-copyright">
						<div class="row">
							<div class="col-lg-12 text-center">
                                <?php if(isset($setting)): ?>
								    <p><?php echo e(w("© Copyright 2021. All Rights Reserved")); ?> <?php echo e($setting->blog_name); ?> </p>
                                <?php endif; ?>

							</div>
						</div>
					</div>

				</div>
			</footer>
		</div>

		<!-- Vendor -->
		<script   src="<?php echo e(asset('frontend/vendor/jquery/jquery.min.js')); ?>"></script>
		<script   src="<?php echo e(asset('frontend/vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
		<script   src="<?php echo e(asset('frontend/vendor/popper/umd/popper.min.js')); ?>"></script>
		<script   src="<?php echo e(asset('frontend/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
		<script   src="<?php echo e(asset('frontend/vendor/isotope/jquery.isotope.min.js')); ?>"></script>
		<script   src="<?php echo e(asset('frontend/vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
		<script   src="<?php echo e(asset('frontend/vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>

		<!-- Theme Base, Components and Settings -->
		<script   src="<?php echo e(asset('frontend/js/theme.js')); ?>"></script>

		<script   src="<?php echo e(asset('frontend/js/demos/demo-construction.js')); ?>"></script>
		<!-- Theme Custom -->
		<script   src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>

		<!-- Theme Initialization Files -->
		<script   src="<?php echo e(asset('frontend/js/theme.init.js')); ?>"></script>
        <script>
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
        </script>

        <script>
            $(function () {
                $('[data-toggle="tooltip"]').tooltip()
            })
        </script>
        <script  src="<?php echo e(asset('vendor/toastr/js/toastr.js')); ?>" type="text/javascript"></script>

            <?php if(app()->getlocale() =="ar"): ?>
                <script>
                    toastr.options = {
                        "closeButton" : true,
                        "debug" : false,
                        "newestOnTop" : true,
                        "progressBar" : true,
                        "positionClass" : "toast-top-left",
                        "preventDuplicates" : false,
                        "onclick" : null,
                        "showDuration" : "500",
                        "hideDuration" : "1800",
                        "timeOut" : "5000",
                        'rtl'   : true,
                        "extendedTimeOut" : "1800",
                        "showEasing" : "swing",
                        "hideEasing" : "linear",
                        "showMethod" : "fadeIn",
                        "hideMethod" : "fadeOut"
                    }
                </script>
            <?php else: ?>
                <script>
                    toastr.options = {
                        "closeButton" : true,
                        "debug" : false,
                        "newestOnTop" : true,
                        "progressBar" : true,
                        "positionClass" : "toast-top-right",
                        "preventDuplicates" : false,
                        "onclick" : null,
                        "showDuration" : "500",
                        "hideDuration" : "1800",
                        "timeOut" : "5000",
                        'rtl'   : false,
                        "extendedTimeOut" : "1800",
                        "showEasing" : "swing",
                        "hideEasing" : "linear",
                        "showMethod" : "fadeIn",
                        "hideMethod" : "fadeOut"
                    }
                </script>
            <?php endif; ?>

            
            <?php echo Toastr::message(); ?>


            <?php echo $__env->yieldPushContent('scripts'); ?>

    

	</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_tasheed-main/resources/views/frontend/front.blade.php ENDPATH**/ ?>