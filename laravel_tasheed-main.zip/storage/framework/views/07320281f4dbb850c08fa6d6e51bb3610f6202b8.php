<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('backend/vendor/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.css')); ?>" rel="stylesheet" type="text/css" />
<style>
    .remove_button{
        width: 62px;
        height: 34px;
        margin-top: 27px;
        text-align: center;
    }
    .removes_buttons{
        width: 62px;
        height: 34px;
        margin-top: 27px;
        text-align: center;
    }

</style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


    <div class="kt-content  kt-grid__item kt-grid__item--fluid" id="kt_content">
        <div class="row">
            <div class="col-md-12">
            <?php echo $__env->make('Manager.included.notfication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--begin::Portlet-->
                <div class="kt-portlet">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                <?php echo e(t("Edit Values")); ?>

                            </h3>
                        </div>
                    </div>


                    <!--begin::Form-->
                    <form autocomplete="off" id="form_input" class="kt-form" action="<?php echo e(route('history.update',$history->id)); ?>"
                          method="POST" enctype="multipart/form-data">

                        <?php echo csrf_field(); ?>
                        <div class="kt-portlet__body">

                            <div class="row">
                                <div class="col-md-12 text-center mb-5">
                                    <div class="kt-avatar kt-avatar--outline kt-avatar--circle-" >
                                        <div class="kt-avatar__holder" id="imagePreview" style="background-image: url(<?php echo e($history->image); ?>);"></div>
                                        <label class="kt-avatar__upload" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-pen"></i>
                                            <input type="file" name="image" id="imageUpload" >
                                        </label>
                                        <span class="kt-avatar__cancel" data-toggle="kt-tooltip" title="" data-original-title="<?php echo e(t('change Image')); ?>">
                                            <i class="fa fa-times"></i>
                                        </span>
                                        <span class="mt-3 d-block text-center">  W 300 / H 225</span>

                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleFormControlTextarea1"><?php echo app('translator')->get("site." . $local . ".Content"); ?></label>
                                            <textarea class="form-control" name="<?php echo e($local); ?>[content]"
                                                id="exampleFormControlTextarea1"
                                                rows="6"><?php echo e($history->translate($local)->content); ?></textarea>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="field_wrapper">
                                <a href="javascript:void(0);" class="add_button  btn btn-success"
                                title="Add field"> <?php echo e(t("Add")); ?></a>
                                <br>
                                <br>
                                <?php if(isset($history->dates)): ?>
                                <?php $__currentLoopData = $history->dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history_dates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <input type="hidden" name="old_history_date_id[]" value="<?php echo e($history_dates->id); ?>">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(t('Year')); ?></label>
                                                <input type="text" name="old_history_date[]"
                                                value="<?php echo e($history_dates->history_date); ?>" class="form-control datetimepicker1" >
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(t('en.Content')); ?></label>
                                                <input type="text" name="old_content_en[]" value="<?php echo e($history_dates->content_en); ?>"  class="form-control" >
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label><?php echo e(t('ar.Content')); ?></label>
                                                <input type="text" name="old_content_ar[]" value="<?php echo e($history_dates->content_ar); ?>"  class="form-control" >
                                            </div>
                                        </div>

                                        <a href='<?php echo e(route('history.deleteHistoryDate',$history_dates->id)); ?>' class='removes_buttons  btn btn-danger btn-sm' ><?php echo e(t('Delete')); ?></a>

                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>


                        </div>
                        <div class="kt-portlet__foot">
                            <div class="kt-form__actions">
                                <button type="submit" class="btn btn-primary"><?php echo e(t('Update Data')); ?></button>
                                <a href="<?php echo e(route('dashboard')); ?>">
                                    <button type="button" class="btn btn-secondary"><?php echo e(t('Reverse')); ?></button>
                                </a>
                            </div>
                        </div>
                    </form>

                    <!--end::Form-->
                </div>

                <!--end::Portlet-->


                <!--end::Portlet-->
            </div>

        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript" src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>

        <?php echo $validator->selector('#form_input'); ?>

        <script src="<?php echo e(asset('backend/vendor/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"  type="text/javascript"></script>
        <script src="<?php echo e(asset('backend/vendor/vendors/bootstrap-datetime-picker/js/bootstrap-datetimepicker.min.js')); ?>"
        type="text/javascript"></script>

        <script>
            $(function () {
                $('.datetimepicker1').datepicker({
                    autoclose : true,
                    orientation: "top left",
                    changeYear: true,
                    format: "yyyy",
                    viewMode: "years",
                    minViewMode: "years"

                });
            });
        </script>

         <script type="text/javascript">
            $(document).ready(function(){
                var maxField = 50; //Input fields increment limitation
                var addButton = $('.add_button'); //Add button selector
                var wrapper = $('.field_wrapper'); //Input field wrapper

                var fieldHTML = "<div class='row'>"+
                "<div class='col-md-3'><div class='form-group'><label><?php echo e(t('Year')); ?></label><input  type='text' name='history_date[]'  class='datetimepicker1 form-control '></div></div>" +
                "<div class='col-md-3'><div class='form-group'><label><?php echo e(t('en.Content')); ?></label><input type='text' name='content_en[]'  class='form-control' ></div></div>" +
                "<div class='col-md-3'><div class='form-group'><label><?php echo e(t('ar.Content')); ?></label><input type='text' name='content_ar[]' class='form-control' ></div></div>" +
                "<a  href='javascript:void(0);' class='remove_button  btn btn-danger btn-sm' ><?php echo e(t('Delete')); ?></a></div>";

                var x = 1; //Initial field counter is 1

                //Once add button is clicked
                $(addButton).click(function(){
                    //Check maximum number of input fields
                    if(x < maxField){
                        x++; //Increment field counter
                        $(wrapper).append(fieldHTML).fadeIn(300); //Add field html
                        jQuery( ".datetimepicker1" ).datepicker({
                            autoclose : true,
                            orientation: "top left",
                            changeYear: true,
                            format: "yyyy",
                            viewMode: "years",
                            minViewMode: "years",
                        });
                    }



                });

                //Once remove button is clicked
                $(wrapper).on('click', '.remove_button', function(e){
                    e.preventDefault();
                    $(".datetimepicker1").datepicker("destroy");
                    $(this).parent('div').remove(); //Remove field html
                    x--; //Decrement field counter
                });



            });


        </script>






    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('Manager.included.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/Manager/dashboard/history/edit.blade.php ENDPATH**/ ?>