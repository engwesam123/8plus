<?php $__env->startSection('title'); ?>
    <?php echo e(w('Projects')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div role="main" class="main">
    <section class="section section-tertiary section-no-border pb-3 mt-0">
        <div class="container">
            <div class="row justify-content-end mt-4">
                <div class="col-lg-10 pt-4 mt-4  <?php if(app()->getlocale() == 'en'): ?> text-rigth  <?php else: ?> text-left <?php endif; ?>">
                    <h1 class="text-uppercase font-weight-light mt-4 pt-3 text-color-primary"><?php echo e(w('Projects')); ?></h1>
                </div>
            </div>
        </div>
    </section>

    <div class="container">

        <div class="row pt-2">
            <div class="col">
                <ul class="nav nav-pills sort-source mb-3 pb-2" data-sort-id="portfolio" data-option-key="filter" data-plugin-options="{'layoutMode': 'fitRows', 'filter': '*'}">
                    <li class="nav-item active" data-option-value="*"><a class="nav-link active" href="#"><?php echo e(w('Show All')); ?></a></li>
                    <?php if(isset($services)): ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($service->projects->count() !== 0): ?>
                            <li class="nav-item" data-option-value=".service<?php echo e($service->id); ?>"><a class="nav-link" href="#"><?php echo e($service->name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </ul>

                <div class="sort-destination-loader sort-destination-loader-showing">
                    <div class="row mb-4 pt-1 portfolio-list sort-destination" data-sort-id="portfolio">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($project): ?>
                                    <div class="col-md-6 col-lg-4 isotope-item mb-4 <?php $__currentLoopData = $project->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> service<?php echo e($pro_service->id); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                                    <a
                                        href="<?php echo e(route('UI.projectDetails',['id' => $project->id,'project_slug' => $project->project_slug ])); ?>">
                                            <span class="thumb-info thumb-info-centered-info thumb-info-no-borders">
                                                <span class="thumb-info-wrapper">
                                                    <img src="<?php echo e($project->image); ?>" class="img-fluid"  alt="<?php echo e(w('Blog Name')); ?> - <?php echo e($project->project_name); ?>">
                                                    <span class="thumb-info-title">
                                                        <span class="thumb-info-inner"><?php echo e(w('View Project...')); ?></span>
                                                    </span>
                                                </span>
                                            </span>
                                        </a>
                                        <h4 class="mt-3 mb-0"> <?php echo e($project->project_name); ?></h4>
                                        <p class="mb-0"><?php echo e($project->location); ?></p>
                                    </div>
                                <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\www\laravel_tasheed-main\resources\views/frontend/projects.blade.php ENDPATH**/ ?>